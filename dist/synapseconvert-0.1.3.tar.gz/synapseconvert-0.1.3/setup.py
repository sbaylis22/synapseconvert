from setuptools import setup, find_packages

setup(
    name="synapseconvert",
    version="0.1.3",
    description="Tools for converting Synapse RTP (research transport protocol) JSON to spreadsheet and back.",
    author="Samuel Baylis",
    author_email="request@biblicalstory.org",
    packages=find_packages(),
    include_package_data=True,
    package_data={"synapseconvert": ["templates/*"]},
    python_requires=">=3.8",
    install_requires=[
        "pandas",
        "openpyxl"
    ],
    entry_points={
        "console_scripts": [
            "synapse-upconvert=synapseconvert.upconvert:main",
            "synapse-downconvert=synapseconvert.downconvert:main",
        ]
    },
)
